<?php
	
	// 1) Incluindo a conexao
	include("../conexao/conexao.php");

	// 2) Montando a $#@*&@# da query
	$querySQL = "SELECT * FROM pessoinhas";

	// 3) Executa a @#*@#% da query
	$resultado = mysqli_query($con,$querySQL);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Listagem</title>
	<meta charset="utf-8">
    
    <!-- Link do CSS/Bootstrap-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- Link do JS/Bootstrap-->


</head>
<body>
	<div class="container">
		<div class="jumbotron">
			<h1>Lista Pessoas</h1>
			<p>Pessoas Lindas!!!</p>
		</div>
	

	<table class="table table-bordered">
		<thead>
			<tr>
				<th>ID</th>
				<th>Nome</th>
				<th>Profissão</th>
				<th>Salário</th>
				<th>Foto</th>
			</tr>
		</thead>

		<?php
		  // 4) Percorrendo resultado
		  while($linha = mysqli_fetch_array($resultado))
		  {
		  	//Inserindo os dados no HTML
		  	echo "
		  			<tr>
		  				<td>".$linha['id']."</td>	
		  				<td>".$linha['nome']."</td>
		  				<td>".$linha['profissao']."</td>
		  				<td>".$linha['salario']."</td>
		  				<td>".$linha['foto']."</td>
		  			</tr>
		  		 ";
		  } 

		?>
	</table>
</div>
</body>
</html>